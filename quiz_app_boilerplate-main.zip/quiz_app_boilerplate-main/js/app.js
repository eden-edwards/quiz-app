function quizpage(){
    location.href = "quiz.html"; 
}

